"""Big-range test by drawn lines (owner-chosen method 1+2, checked by eye 2026-10-09: 19 right,
5 close, 0 wrong at big swing size 4).

Big swings: zigzag reversal >= BIG_K x ATR14. Candidate touches are small swings (1.5 ATR) and big
swings within the SHOW sessions before t, all confirmed by t-1. Touch prices close within TOL x ATR
are clustered into a horizontal line. A line needs >= 2 touches, at least one of them a big swing.
Inside the big range = a resistance line still lies above the breakout close.
BODY=True uses the candle body edge (max(open, close)) as the touch price instead of the wick
high, following the owner's note that a spike wick is not where he would draw the line."""
from __future__ import annotations

import numpy as np

from detect import pivots_atr

SMALL_K, BIG_K, TOL, SHOW = 1.5, 4.0, 0.75, 200


def resistance_above(o, h, l, c, atr, t, body=False):
    s = max(0, t - SHOW)
    top = np.maximum(o, c)
    price = (lambda i, p: float(top[i])) if body else (lambda i, p: float(p))
    sh, _ = pivots_atr(h, l, c, atr, k=SMALL_K)
    bh, _ = pivots_atr(h, l, c, atr, k=BIG_K)
    small = {i: price(i, p) for i, cf, p in sh if cf <= t - 1 and i >= s}
    big = {i: price(i, p) for i, cf, p in bh if cf <= t - 1 and i >= s}
    pts = sorted({**small, **big}.items(), key=lambda x: x[1])
    groups, cur = [], []
    for i, p in pts:
        if cur and abs(p - np.median([q for _, q in cur])) > TOL * atr[i]:
            groups.append(cur)
            cur = []
        cur.append((i, p))
    if cur:
        groups.append(cur)
    lines = [(float(np.median([p for _, p in g])), len(g)) for g in groups if len(g) >= 2 and any(i in big for i, _ in g)]
    return [ln for ln in lines if ln[0] > c[t]]
