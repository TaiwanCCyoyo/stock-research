"""Draft definitions of 頭頭高底底高 (owner's 2B) for discussion; examples only, NO outcomes read.
Input: atlas-v2 per-stock tables (adjusted OHLC). Output: examples.json for the review page."""
import json, random
from pathlib import Path
import numpy as np, pandas as pd

TABLES = Path("D:/Project/Stock/tasks/20261004-feature-discrimination-atlas/datasets/atlas-v2/tables")
OUT = Path(__file__).with_name("examples.json")
N = 5  # pivot half-width

def pivots_fixed(h, l, n=N):
    """pivot highs/lows with n bars each side; returns lists of (idx, confirm_idx, price)."""
    ph, pl = [], []
    for i in range(n, len(h) - n):
        if h[i] == h[i-n:i+n+1].max() and h[i] > h[i-n:i].max(): ph.append((i, i + n, h[i]))
        if l[i] == l[i-n:i+n+1].min() and l[i] < l[i-n:i].min(): pl.append((i, i + n, l[i]))
    return ph, pl

def pivots_atr(h, l, c, atr, k=2.0):
    """zigzag: an extreme is confirmed once price reverses k*ATR away from it."""
    ph, pl = [], []
    mode, ext_i = 0, 0  # mode 1 tracking a high, -1 tracking a low
    for i in range(1, len(c)):
        a = atr[i]
        if not np.isfinite(a) or a <= 0: continue
        if mode == 0:
            mode, ext_i = 1, i
            continue
        if mode == 1:
            if h[i] >= h[ext_i]: ext_i = i
            elif h[ext_i] - l[i] >= k * a:
                ph.append((ext_i, i, h[ext_i])); mode, ext_i = -1, i
        else:
            if l[i] <= l[ext_i]: ext_i = i
            elif h[i] - l[ext_i] >= k * a:
                pl.append((ext_i, i, l[ext_i])); mode, ext_i = 1, i
    return ph, pl

def scan(h, l, c, ph, pl, rule, atr):
    sig, used = [], set()
    j = 0
    for t in range(1, len(c)):
        # latest pivot high confirmed by t-1
        hs = [p for p in ph if p[1] <= t - 1]
        if not hs: continue
        i1, _, H1 = hs[-1]
        if i1 in used or t - i1 < 2: continue
        ls = [p for p in pl if p[1] <= t - 1 and p[0] < i1]
        if not ls: continue
        k1, _, L1 = ls[-1]
        L2 = l[i1+1:t].min(); k2 = i1 + 1 + int(l[i1+1:t].argmin())
        if not L2 > L1: 
            continue
        if rule == "A":
            ok = h[t] > H1
        elif rule == "B":
            ok = (H1 - L2) / H1 >= 0.05 and c[t] >= H1 * 1.01
        else:
            ok = np.isfinite(atr[t]) and c[t] >= H1 + 0.5 * atr[t]
        if ok:
            used.add(i1)
            sig.append(dict(t=t, h1=i1, l1=k1, l2=k2, H1=float(H1), L1=float(L1), L2=float(L2)))
        elif rule != "A" and c[t] > H1 * (1.01 if rule == "B" else 1) and False:
            pass
    return sig

def main():
    rng = random.Random(20261005)
    res = {"A": [], "B": [], "C": [], "F33": []}
    stats = {k: {"signals": 0, "stock_years": 0.0} for k in res}
    thin = 0
    files = sorted(TABLES.glob("*.parquet"))
    for f in files:
        df = pd.read_parquet(f, columns=["asof_date", "Open", "High", "Low", "Close", "atr14_pct", "F33"])
        df = df.dropna(subset=["Open", "High", "Low", "Close"]).reset_index(drop=True)
        if len(df) < 80: continue
        o, h, l, c = (df[x].to_numpy(float) for x in ("Open", "High", "Low", "Close"))
        atr = (df["atr14_pct"].to_numpy(float) * c)
        yrs = len(df) / 245
        ph, pl = pivots_fixed(h, l)
        zh, zl = pivots_atr(h, l, c, atr)
        code = f.stem
        for rule, (P, Q) in {"A": (ph, pl), "B": (ph, pl), "C": (zh, zl)}.items():
            s = scan(h, l, c, P, Q, rule, atr)
            stats[rule]["signals"] += len(s); stats[rule]["stock_years"] += yrs
            if rule == "A":
                thin += sum(1 for x in s if (h[x["t"]] - x["H1"]) / x["H1"] < 0.005)
            for x in s:
                x["code"] = code; x["df"] = df
            res[rule].extend((rng.random(), x) for x in s)
        fl = df["F33"].fillna(False).to_numpy(bool)
        f33 = [t for t in np.flatnonzero(fl) if t == 0 or not fl[t-1]]
        stats["F33"]["signals"] += len(f33); stats["F33"]["stock_years"] += yrs
        res["F33"].extend((rng.random(), dict(t=int(t), code=code, df=df)) for t in f33)

    def window(x, start):
        df = x["df"]; t = x["t"]
        w = df.iloc[start:t+1]
        return [[d, round(a, 2), round(b, 2), round(cc, 2), round(e, 2)] for d, a, b, cc, e in
                zip(w["asof_date"].astype(str), w["Open"], w["High"], w["Low"], w["Close"])]

    out = {"stats": {}, "examples": {}}
    for k, v in stats.items():
        out["stats"][k] = {"signals": v["signals"], "per_stock_year": round(v["signals"] / v["stock_years"], 2)}
    out["stats"]["A_thin_break_share"] = round(thin / max(stats["A"]["signals"], 1), 3)
    for rule, items in res.items():
        items.sort(key=lambda z: z[0])
        ex = []
        for _, x in items[:6]:
            start = max(0, (x.get("l1", x["t"] - 40)) - 15) if rule != "F33" else max(0, x["t"] - 45)
            start = min(start, x["t"] - 30) if x["t"] >= 30 else 0
            e = {"code": x["code"], "date": str(x["df"]["asof_date"].iloc[x["t"]])[:10], "bars": window(x, start)}
            if rule != "F33":
                e.update({k2: x[k2] - start for k2 in ("l1", "h1", "l2", "t")})
                e.update({k2: round(x[k2], 2) for k2 in ("H1", "L1", "L2")})
                if rule == "C": e["atr"] = round(float(x["df"]["atr14_pct"].iloc[x["t"]] * x["df"]["Close"].iloc[x["t"]]), 2)
            else:
                e["t"] = x["t"] - start
                lo = x["df"]["Low"].to_numpy(float); t = x["t"]
                for b in range(t - 1, max(20, t - 6), -1):
                    if lo[b] < lo[b-20:b].min():
                        e["level"] = round(float(lo[b-20:b].min()), 2); e["brk"] = b - start; break
            ex.append(e)
        out["examples"][rule] = ex
    OUT.write_text(json.dumps(out, ensure_ascii=False))
    print(json.dumps(out["stats"], indent=1))

if __name__ == "__main__":
    main()
