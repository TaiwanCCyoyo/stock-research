import os
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
import sys
from pathlib import Path
sys.path.insert(0, 'D:/Project/stock-research/.worktrees/pr17-scratch-continuation')
import cProfile
import json
import pstats
import time
from types import SimpleNamespace
import pandas as pd
import pyarrow as pa
from research_core.pattern_scan_parquet_v1 import read_frame
from research_core.pattern_scan_local_inputs_v5 import group_frame
from research_core.pattern_scan_followup_v1 import followup_values
from research_core.live_producer import assert_producer_idle
pa.set_cpu_count(1)
pa.set_io_thread_count(1)
assert_producer_idle(task_timeout=15)
root = Path('D:/StockData/stock-research/scratch/20261013-pattern-scan/q2-q6-v6')
original = Path('D:/Project/stock-research/.tmp/pattern-scan-execution/full-2010-20261016-retention-v3')
receipt = json.loads((original / 'phase-stock-result.json').read_text())
parts = {r['code']: Path(r['output_path']) for r in receipt['pool']['results']}
result = []
for code in ('1514', '2002', '3030'):
    directory = root / '_temporary/events/L2' / code
    if not directory.is_dir():
        print('missing', code, flush=True)
        continue
    bound = SimpleNamespace(**{n: read_frame(directory / (n+'.parquet')) for n in ('events','conditions','group_memberships')})
    events = pd.concat([group_frame(bound, 'pattern:union', h) for h in (126,252)], ignore_index=True)
    frame = read_frame(parts[code] / 'indicators.parquet')
    pivots = read_frame(parts[code] / 'pivots.parquet')
    begin = time.perf_counter()
    tables = followup_values(events, frame, pivots)
    wall = time.perf_counter()-begin
    del tables
    profile = cProfile.Profile()
    profile.enable()
    tables = followup_values(events, frame, pivots)
    profile.disable()
    stats = pstats.Stats(profile)
    rows = [{'file':Path(k[0]).name,'line':k[1],'function':k[2],'calls':v[1],'self_seconds':v[2],'cumulative_seconds':v[3]} for k,v in stats.stats.items()]
    record = {'code':code,'events':len(events),'unprofiled_wall_seconds':wall,'profile_total_seconds':stats.total_tt,'top_cumulative':sorted(rows,key=lambda r:r['cumulative_seconds'],reverse=True)[:25]}
    result.append(record)
    print(json.dumps(record), flush=True)
Path('D:/Project/stock-research/.tmp/pr17-followup-profile-results.json').write_text(json.dumps(result,indent=2))
