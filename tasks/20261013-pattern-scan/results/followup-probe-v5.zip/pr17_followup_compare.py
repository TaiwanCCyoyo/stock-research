"""Read-only real-input comparison; no study publication or input copies."""
import os
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import sys
from pathlib import Path
ROOT=Path('D:/Project/stock-research/.worktrees/pr17-followup-performance')
OLD=Path('D:/Project/stock-research/.worktrees/pr17-scratch-continuation')
sys.path.insert(0,str(ROOT))
import importlib.util
import json
import time
from dataclasses import fields
from types import SimpleNamespace
import pandas as pd
import pyarrow as pa
from research_core.pattern_scan_parquet_v1 import read_frame
from research_core.pattern_scan_local_inputs_v5 import group_frame
from research_core.pattern_scan_followup_v1 import followup_values
from research_core.live_producer import assert_producer_idle
pa.set_cpu_count(1)
pa.set_io_thread_count(1)
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    return module
old_flags=load('probe_old_flags',OLD/'research_core/pattern_scan_flags_v1.py')
old_followup=load('probe_old_followup',OLD/'research_core/pattern_scan_followup_v1.py')
old_followup.event_flags=old_flags.event_flags
old_followup.event_flag_observations=old_flags.event_flag_observations
assert_producer_idle(task_timeout=15)
run=Path('D:/StockData/stock-research/scratch/20261013-pattern-scan/q2-q6-v6')
original=Path('D:/Project/stock-research/.tmp/pattern-scan-execution/full-2010-20261016-retention-v3')
receipt=json.loads((original/'phase-stock-result.json').read_text())
parts={r['code']:Path(r['output_path']) for r in receipt['pool']['results']}
records=[]
for code in ('1514','2002','3030'):
    directory=run/'_temporary/events/L2'/code
    bound=SimpleNamespace(**{n:read_frame(directory/(n+'.parquet')) for n in ('events','conditions','group_memberships')})
    events=pd.concat([group_frame(bound,'pattern:union',h) for h in (126,252)],ignore_index=True)
    frame=read_frame(parts[code]/'indicators.parquet')
    pivots=read_frame(parts[code]/'pivots.parquet')
    arms={'old':old_followup.followup_values,'new':followup_values}
    for repeat,order in enumerate((('old','new'),('new','old'))):
        outputs={}
        measures={}
        for arm in order:
            start=time.perf_counter(); cpu=time.process_time()
            outputs[arm]=arms[arm](events,frame,pivots)
            measures[arm]={'wall_seconds':time.perf_counter()-start,'cpu_seconds':time.process_time()-cpu}
        for field in fields(outputs['new']):
            pd.testing.assert_frame_equal(getattr(outputs['old'],field.name),getattr(outputs['new'],field.name),check_exact=True)
        record={'code':code,'events':len(events),'repeat':repeat,'order':order,'measurements':measures,'exact_equal':True}
        records.append(record)
        print(json.dumps(record),flush=True)
        del outputs
Path('D:/Project/stock-research/.tmp/pr17-followup-comparison-results.json').write_text(json.dumps(records,indent=2))
