import sys
import json
import time
from pathlib import Path
sys.path.insert(0,'D:/Project/stock-research/.worktrees/pr17-followup-performance')
from research_core.pattern_scan_execution_v1 import _MemoryBoundJob
job=_MemoryBoundJob(2*1024**3)
start=time.perf_counter()
timed_out=False
try:
    process=job.start([sys.executable,'D:/Project/stock-research/.tmp/pr17_followup_compare.py'],Path('D:/Project/stock-research/.worktrees/pr17-followup-performance'))
    import subprocess
    try:
        code=process.wait(timeout=240)
    except subprocess.TimeoutExpired:
        timed_out=True
        job.terminate_and_confirm()
        code=process.wait(timeout=5)
    record={**job.memory_receipt(),'exit_code':code,'timed_out':timed_out,'wall_seconds':time.perf_counter()-start}
    Path('D:/Project/stock-research/.tmp/pr17-followup-comparison-job.json').write_text(json.dumps(record,indent=2))
    print(json.dumps(record),flush=True)
finally:
    job.terminate_and_confirm()
    job.close()
