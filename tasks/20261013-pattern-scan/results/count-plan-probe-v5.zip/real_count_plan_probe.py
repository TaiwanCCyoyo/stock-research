"""Read-only four-stock differential engineering check; no study publication."""
import os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','BLIS_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'
import json
import subprocess
import sys
import time
import types
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import pandas as pd
from research_core.live_producer import assert_producer_idle
from research_core.hhhl_variants_selection import split_for_code
from research_core.pattern_scan_local_inputs_v5 import LocalInputs, group_frame
from research_core.pattern_scan_local_conditions_v5 import _selection_record, _metadata
from research_core.pattern_scan_membership_v1 import StockCountPlan, membership_inventory

def main():
    assert_producer_idle(task_timeout=15)
    run = Path('D:/StockData/stock-research/scratch/20261013-pattern-scan/q2-q6-v6')
    stock = Path('D:/Project/stock-research/.tmp/pattern-scan-execution/full-2010-20261016-retention-v3/phase-stock-result.json')
    inputs = LocalInputs(stock, run / '_temporary')
    inputs.projection_build_allowed = False
    inputs.attach_target('B3', run / '_temporary/events/B3', require_complete=True)
    _, candidates = _selection_record(run / 'B3/.staging-conditions/B3-selection.json', 'B3')
    inventory = tuple(row for row in membership_inventory(_metadata('B3','C-base-all',126),candidates)
                      if row['feature_id'] != 'unconditional' and (row['feature_id'] != 'candidate' or row['split'] == 'cross-check'))
    baseline = '73635cee35b74b72d561eae1864ce6b0779992b8'
    module = types.ModuleType('research_core.pr17_legacy_count_probe')
    module.__file__ = str(ROOT / 'research_core/pattern_scan_membership_v1.py')
    module.__package__ = 'research_core'
    sys.modules[module.__name__] = module
    source = subprocess.check_output(['git','show',baseline+':research_core/pattern_scan_membership_v1.py'],cwd=ROOT)
    exec(compile(source,module.__file__,'exec'),module.__dict__)
    plans = {}
    construction = {}
    for name, cls in [('old',module.StockCountPlan),('new',StockCountPlan)]:
        t = time.perf_counter()
        plans[name] = cls(inventory,max_membership_rows=2_000_000)
        construction[name] = time.perf_counter()-t
    codes = sum(([code for code in inputs.codes if split_for_code(code) == split][:2] for split in ('development','cross-check')), [])
    rows = []
    for n, code in enumerate(codes):
        t = time.perf_counter()
        frame = group_frame(inputs.bound('B3',code),'C-base-all',126)
        read_wall = time.perf_counter()-t
        result = {'code':code,'split':split_for_code(code),'events':len(frame),'read_wall_seconds':read_wall}
        matrices = {}
        for name in (('old','new') if n % 2 == 0 else ('new','old')):
            t, cpu = time.perf_counter(),time.process_time()
            matrices[name] = plans[name].matrix(frame)
            result[name] = {'wall_seconds':time.perf_counter()-t,'cpu_seconds':time.process_time()-cpu}
        pd.testing.assert_frame_equal(matrices['old'],matrices['new'],check_exact=True,check_dtype=True)
        result.update(matrix_rows=len(matrices['new']),exact_equal=True)
        rows.append(result)
        print(json.dumps(result),flush=True)
    report = {'kind':'bounded four-stock engineering differential, not full-market capacity',
              'baseline_commit':baseline,'candidate_n':len(candidates),'source_id':inputs.source_id,'input_id':inputs.input_id,
              'original_universe_n':len(inputs.codes),'plan_construction_wall_seconds':construction,'stocks':rows}
    (ROOT/'.tmp/real-count-plan-probe.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')

if __name__ == '__main__':
    main()
