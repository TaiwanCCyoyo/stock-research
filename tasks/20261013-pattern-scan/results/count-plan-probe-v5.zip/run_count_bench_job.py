"""Session-owned bounded engineering runner; never writes study checkpoints."""
import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from research_core.pattern_scan_execution_v1 import _MemoryBoundJob

parser = argparse.ArgumentParser()
parser.add_argument('--receipt', type=Path, required=True)
parser.add_argument('--timeout', type=int, default=900)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ['--'] else args.command
job = _MemoryBoundJob(8 * 1024**3)
started = time.perf_counter()
code = None
timed_out = False
try:
    process = job.start(command, ROOT)
    try:
        code = process.wait(timeout=args.timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
finally:
    receipt = {**job.memory_receipt(), 'wall_seconds': time.perf_counter()-started,
               'exit_code': code, 'timed_out': timed_out, 'command': command}
    job.terminate_and_confirm()
    job.close()
    args.receipt.write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
print(json.dumps(receipt))
sys.exit(124 if timed_out else code if code is not None else 1)
