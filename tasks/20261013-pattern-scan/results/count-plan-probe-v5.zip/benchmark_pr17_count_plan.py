"""Bounded synthetic StockCountPlan diagnostic; never reads research inputs."""

from __future__ import annotations

import argparse
import json
import logging
import multiprocessing as mp
import os
from pathlib import Path
import subprocess
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from itertools import combinations
from types import ModuleType
from typing import Any

# Spawned processes execute this before any numerical-library imports.
THREAD_ENV = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "BLIS_NUM_THREADS")
for _name in THREAD_ENV:
    os.environ[_name] = "1"

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
BASELINE = "73635cee35b74b72d561eae1864ce6b0779992b8"
EVENTS = 4110
JOBS = 40
HORIZON = 126
LOGGER = logging.getLogger("count-plan-benchmark")
_PLAN: Any = None


def stamp() -> tuple[float, float]:
    return time.perf_counter(), time.process_time()


def elapsed(start: tuple[float, float]) -> dict[str, float]:
    return {"wall_seconds": time.perf_counter() - start[0], "cpu_seconds": time.process_time() - start[1]}


def libraries() -> None:
    global np, pd, Atom, split_for_code, FEATURES, StockCountPlan, membership_inventory, COUNT_FIELDS
    import numpy as np
    import pandas as pd
    from research_core.hhhl_variants_selection import Atom, split_for_code
    from research_core.pattern_scan_conditions_v1 import FEATURES
    from research_core.pattern_scan_membership_v1 import StockCountPlan, membership_inventory
    from research_core.pattern_scan_summary_store_v1 import COUNT_FIELDS


def inventory() -> tuple[dict[str, Any], ...]:
    """Eight distinct family atoms produce 8 + 28 + 56 = 92 candidates."""
    atoms: dict[str, Any] = {}
    for feature, definition in FEATURES.items():
        if not definition.diagnostic_only and definition.family not in atoms:
            atoms[definition.family] = Atom(definition.family, feature, definition.bin_ids[0])
        if len(atoms) == 8:
            break
    if len(FEATURES) != 52 or len(atoms) != 8:
        raise ValueError("benchmark requires the expected 52 features and 8 available families")
    candidates = {
        f"synthetic-{index:03d}": members
        for index, members in enumerate(combo for size in (1, 2, 3) for combo in combinations(atoms.values(), size))
    }
    if len(candidates) != 92:
        raise ValueError("benchmark candidate count drifted")
    base = {"pattern_id": "B3", "control_id": "C-base-all", "cohort_id": "all", "horizon": HORIZON}
    # Match local_conditions_v5: Q1 is complete; candidates only cross-check.
    return tuple(
        row for row in membership_inventory(base, candidates)
        if row["feature_id"] != "unconditional" and (row["feature_id"] != "candidate" or row["split"] == "cross-check")
    )


def stock_code(job: int) -> str:
    """Alternate splits, including cross-check for the differential reference."""
    desired = "cross-check" if job % 2 == 0 else "development"
    matches = (str(number) for number in range(1000, 10000) if split_for_code(str(number)) == desired)
    for index, code in enumerate(matches):
        if index == job // 2:
            return code
    raise ValueError("synthetic code inventory exhausted")


def frame_for(job: int) -> Any:
    rng = np.random.default_rng(20261028 + job)
    code = stock_code(job)
    # Monotone dates span all 17 years; unique IDs are independent of dates.
    dates = pd.bdate_range("2010-01-04", "2026-10-27")
    selected = dates[np.linspace(0, len(dates) - 1, EVENTS, dtype=int)]
    labels = rng.choice(np.array(["hit", "loss", "flat-win", "unknown"], dtype=object), EVENTS, p=[0.35, 0.3, 0.23, 0.12])
    full = rng.random(EVENTS) >= 0.1
    excluded = rng.random(EVENTS) < 0.08
    columns: dict[str, Any] = {
        "security_id": np.full(EVENTS, f"TW:{code}", dtype=object),
        "event_id": np.array([f"synthetic-{job}-{index}" for index in range(EVENTS)], dtype=object),
        "t0": selected.strftime("%Y-%m-%d").to_numpy(dtype=object),
        "horizon": np.full(EVENTS, HORIZON, dtype=np.int64),
        "mkt": rng.choice(np.array(["up", "down", "consolidation", "mixed", "unknown"], dtype=object), EVENTS),
        "effective_label": labels,
        "calendar_full": full,
        "event_eligibility_excluded": excluded,
        "event_main_eligible": full & (labels != "unknown") & ~excluded,
    }
    for feature, definition in FEATURES.items():
        statuses = rng.choice(np.array(["known", "feature_unknown", "not_applicable"], dtype=object), EVENTS, p=[0.84, 0.1, 0.06])
        bins = rng.choice(np.array(tuple(dict.fromkeys(definition.bin_ids)), dtype=object), EVENTS)
        bins[statuses != "known"] = None
        columns[f"{feature}_bin"] = bins
        columns[f"{feature}_status"] = statuses
    return pd.DataFrame(columns)


def summary(matrix: Any) -> dict[str, Any]:
    return {"rows": len(matrix), "count_totals": {field: int(matrix[field].sum()) for field in COUNT_FIELDS}}


def baseline_class() -> Any:
    source = subprocess.run(
        ["git", "show", f"{BASELINE}:research_core/pattern_scan_membership_v1.py"],
        cwd=ROOT, check=True, capture_output=True, text=True, encoding="utf-8",
    ).stdout
    module = ModuleType("research_core._benchmark_old_membership")
    module.__file__ = f"git:{BASELINE}:research_core/pattern_scan_membership_v1.py"
    sys.modules[module.__name__] = module
    exec(compile(source, module.__file__, "exec"), module.__dict__)
    return module.StockCountPlan


def single_stock(include_baseline: bool, cap: int) -> dict[str, Any]:
    started = stamp()
    rows = inventory()
    frame = frame_for(0)
    result: dict[str, Any] = {"fixture_setup": elapsed(started), "inventory_rows": len(rows)}
    if include_baseline:
        started = stamp()
        old_class = baseline_class()
        result["baseline_module_load"] = elapsed(started)
        started = stamp()
        old_plan = old_class(rows, max_membership_rows=cap)
        result["old_plan_construction"] = elapsed(started)
        started = stamp()
        old_matrix = old_plan.matrix(frame)
        result["old_matrix"] = elapsed(started)
    started = stamp()
    plan = StockCountPlan(rows, max_membership_rows=cap)
    result["new_plan_construction"] = elapsed(started)
    started = stamp()
    matrix = plan.matrix(frame)
    result["new_matrix"] = elapsed(started)
    result["summary"] = summary(matrix)
    if include_baseline:
        started = stamp()
        pd.testing.assert_frame_equal(old_matrix, matrix, check_exact=True)
        result["parity_verification"] = {**elapsed(started), "exact_equal": True, "includes_dtypes_order_index": True}
        result["matrix_wall_speedup"] = result["old_matrix"]["wall_seconds"] / result["new_matrix"]["wall_seconds"]
    else:
        result["parity_verification"] = {"status": "skipped; enable --baseline for one old/new differential"}
    return result


def worker_init(cap: int, ready: Any, barrier: Any) -> None:
    global _PLAN
    started = stamp()
    libraries()
    imports = elapsed(started)
    started = stamp()
    rows = inventory()
    fixture = elapsed(started)
    started = stamp()
    _PLAN = StockCountPlan(rows, max_membership_rows=cap)
    ready.put({"pid": os.getpid(), "imports": imports, "inventory_setup": fixture, "plan_construction": elapsed(started)})
    barrier.wait()


def worker_job(job: int) -> dict[str, Any]:
    started = stamp()
    frame = frame_for(job)
    setup = elapsed(started)
    started = stamp()
    matrix = _PLAN.matrix(frame)
    count = elapsed(started)
    started = stamp()
    totals = summary(matrix)
    return {"job": job, "pid": os.getpid(), "frame_setup": setup, "matrix": count, "summary": totals, "summary_setup": elapsed(started)}


def parallel_run(workers: int, cap: int) -> dict[str, Any]:
    context = mp.get_context("spawn")
    ready = context.Queue()
    barrier = context.Barrier(workers + 1)
    started = stamp()
    with ProcessPoolExecutor(max_workers=workers, mp_context=context, initializer=worker_init, initargs=(cap, ready, barrier)) as executor:
        futures = [executor.submit(worker_job, job) for job in range(JOBS)]
        initializers = [ready.get(timeout=180) for _ in range(workers)]
        setup = elapsed(started)
        started = stamp()
        barrier.wait(timeout=180)
        results = [future.result() for future in futures]
        count = elapsed(started)
    ready.close()
    ready.join_thread()
    by_pid: dict[int, Any] = {}
    for row in results:
        entry = by_pid.setdefault(row["pid"], {"jobs": 0, "matrix_cpu_seconds": 0.0, "matrix_wall_seconds": 0.0, "frame_setup_cpu_seconds": 0.0, "frame_setup_wall_seconds": 0.0})
        entry["jobs"] += 1
        for phase in ("matrix", "frame_setup"):
            for unit in ("cpu_seconds", "wall_seconds"):
                entry[f"{phase}_{unit}"] += row[phase][unit]
    return {
        "workers_requested": workers, "worker_pids": sorted(by_pid), "jobs": JOBS,
        "pool_setup_parent": setup, "pool_execution_parent": count,
        "worker_initializers": initializers, "worker_totals": by_pid,
        "worker_matrix_cpu_seconds_total": sum(row["matrix"]["cpu_seconds"] for row in results),
        "worker_matrix_wall_seconds_sum": sum(row["matrix"]["wall_seconds"] for row in results),
        "jobs_per_second": JOBS / count["wall_seconds"],
        "job_results": results,
    }


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="New diagnostic JSON path inside this worktree's .tmp")
    parser.add_argument("--baseline", action="store_true", help="Compare exactly one full synthetic stock against the old implementation")
    parser.add_argument("--workers", type=int, choices=(1, 4, 8, 10), nargs="*", default=[], help="Optional new-only 40-stock process-pool runs")
    parser.add_argument("--max-membership-rows", type=int, default=2_000_000)
    return parser.parse_args()


def main() -> int:
    args = arguments()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    output = args.output.resolve()
    allowed = (ROOT / ".tmp").resolve()
    if not output.is_relative_to(allowed) or output == allowed or output.exists() or args.max_membership_rows < 1:
        LOGGER.error("Output must be a new file under %s; membership cap must be positive", allowed)
        return 2
    report: dict[str, Any] = {
        "schema": "pr17-synthetic-count-plan-benchmark.v1", "status": "running",
        "scope": "engineering synthetic diagnostic; no research data, source hashes, or intermediate hashes",
        "baseline_commit": BASELINE if args.baseline else None,
        "configuration": {"events_per_stock": EVENTS, "years": [2010, 2026], "features": 52, "candidates": 92, "candidate_families": 8, "jobs_per_pool": JOBS, "nested_threads": 1, "max_membership_rows": args.max_membership_rows},
        "timing_notes": "CPU is process_time: pool parent CPU excludes workers; per-worker CPU is recorded separately. Worker wall sums are not elapsed pool wall time. Pool execution excludes initializer/setup and shutdown; includes frame generation, summary, and IPC. Exact parity is outside count timers.",
        "pools": [],
    }
    try:
        started = stamp()
        libraries()
        report["parent_imports"] = elapsed(started)
        LOGGER.info("Single-stock comparison baseline=%s", args.baseline)
        report["single_stock"] = single_stock(args.baseline, args.max_membership_rows)
        prior_summaries = None
        for workers in dict.fromkeys(args.workers):
            LOGGER.info("New-only pool workers=%d jobs=%d", workers, JOBS)
            run = parallel_run(workers, args.max_membership_rows)
            summaries = [row["summary"] for row in run["job_results"]]
            if prior_summaries is not None and summaries != prior_summaries:
                raise AssertionError("Worker-count runs disagree on per-stock rows/count totals")
            run["summary_consistency"] = "reference" if prior_summaries is None else "equal to first pool; scalar summaries only"
            prior_summaries = summaries
            report["pools"].append(run)
        report["status"] = "passed"
    except Exception as error:
        LOGGER.exception("Benchmark failed")
        report["status"] = "failed"
        report["error"] = {"type": type(error).__name__, "message": str(error)}
    try:
        with output.open("x", encoding="utf-8", newline="\n") as handle:
            json.dump(report, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
    except OSError:
        LOGGER.exception("Cannot write diagnostic report: %s", output)
        return 2
    LOGGER.info("Diagnostic status=%s output=%s", report["status"], output)
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    mp.freeze_support()
    raise SystemExit(main())
