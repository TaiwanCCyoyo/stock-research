Bounded five-stock L1 recovery evidence, 2026-11-03.
No market four-cell or full-market results.
Pilot source commit: 37f08f871faa44abf1263379c73608f90862d405.
The original receipt retains external run paths; files are preserved byte-identically under pilot/.
verification.json checks 468 selected Q1/marginal summary and annual rows against shared direct counts.
Reproduce with tasks/20261013-pattern-scan/verify_l1_recovery_pilot.py and the retained run path.
The first attempt stopped before projection due to historical runtime validation; its failure evidence is retained.
