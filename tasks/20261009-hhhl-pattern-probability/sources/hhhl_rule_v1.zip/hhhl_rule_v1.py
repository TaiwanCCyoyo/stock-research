"""Owner HH/HL pattern, rule v1 (frozen 2026-10-08 before batch 3). Do not edit; a change is v2.

Built from the owner's labels and critiques of 2026-10-05..08 (batches 1-2, rule-critique round).
All decisions on session t use only data through t (swings must be confirmed by t-1).

1. Swings: zigzag on wick highs/lows; a swing is confirmed once price reverses >= 1.5 x ATR14.
2. Relation of a swing to the previous same-kind zone: gap < -0.5 ATR lower, > +0.75 ATR higher,
   otherwise the same zone (merged).
3. Restart: the latest low whose relation is lower (or the first low) starts the current structure.
4. Breakout on t: the first close above the top of the latest confirmed high zone, with
   close > highest close of the prior 20 sessions and volume >= 1.5 x their mean.
5. Category from the low zones: hhhl (latest low higher), bottom (hhhl after falling lows),
   range (latest low in the same zone, or the broken high zone has >= 2 highs); none = no pattern.
6. Big-scale context over the 90 sessions before the restart: the event is a pattern if the
   breakout close clears their highest close, or they fell (net change <= -0.5 x their range);
   otherwise it is tagged inside_big_range and is not a pattern.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from detect import pivots_atr

K, LO_CUT, HI_CUT, HI20, VOLX, LOOK, DEC = 1.5, -0.5, 0.75, 20, 1.5, 90, -0.5


def _pivots(h, l, c, atr):
    ph, pl = pivots_atr(h, l, c, atr, k=K)
    return sorted([(i, cf, p, "H") for i, cf, p in ph] + [(i, cf, p, "L") for i, cf, p in pl], key=lambda x: x[1])


def _structure(piv, t, atr):
    """Zones and per-swing relations from swings confirmed by t-1."""
    zones, ref, seq = {"H": [], "L": []}, {}, []
    for i, cf, p, k in piv:
        if cf > t - 1:
            break
        zs = zones[k]
        if zs:
            g = (p - zs[-1]["ref"]) / atr[i]
            rel = "same" if LO_CUT <= g <= HI_CUT else ("higher" if g > HI_CUT else "lower")
        else:
            rel = "first"
        if rel == "same":
            z = zs[-1]; z["n"] += 1; z["top"] = max(z["top"], p); z["last"] = i
        else:
            zs.append(dict(ref=p, top=p, n=1, first=i, last=i, rel=rel))
        seq.append(dict(i=i, k=k, p=float(p), rel=rel))
    return zones, seq


def detect(df: pd.DataFrame) -> list[dict]:
    """df needs Open, High, Low, Close, VolumeLots, atr14_pct (atlas-v2 per-stock table)."""
    o, h, l, c = (df[x].to_numpy(float) for x in ("Open", "High", "Low", "Close"))
    v = df["VolumeLots"].to_numpy(float)
    atr = df["atr14_pct"].to_numpy(float) * c
    piv = _pivots(h, l, c, atr)
    out, broken = [], set()
    for t in range(HI20 + 1, len(c)):
        zones, seq = _structure(piv, t, atr)
        if not zones["H"] or len(zones["L"]) < 2:
            continue
        hz = zones["H"][-1]
        key = (hz["first"], hz["ref"])
        if key in broken or not (c[t] > hz["top"] and c[t - 1] <= hz["top"]):
            continue
        broken.add(key)
        mean_v = np.nanmean(v[t - HI20:t])
        vx = v[t] / mean_v if mean_v > 0 else np.nan
        if not (c[t] > c[t - HI20:t].max() and vx >= VOLX):
            continue
        lows = [z for z in zones["L"] if z["first"] < t]
        last, prev = lows[-1], lows[-2]
        if last["rel"] == "higher":
            cat = "bottom" if len(lows) >= 3 and prev["rel"] == "lower" else "hhhl"
        elif last["rel"] == "same" or last["n"] >= 2 or hz["n"] >= 2:
            cat = "range"
        else:
            continue
        low_idx = [j for j, q in enumerate(seq) if q["k"] == "L"]
        rs_j = next((j for j in reversed(low_idx) if seq[j]["rel"] in ("lower", "first")), low_idx[0])
        rs = seq[rs_j]["i"]
        W = c[max(0, rs - LOOK):rs]
        if len(W) < 20 or c[t] >= W.max():
            context = "clears"
        elif (W[-1] - W[0]) / (W.max() - W.min()) <= DEC:
            context = "after_decline"
        else:
            context = "inside_big_range"
        out.append(dict(t=t, cat=cat, context=context, pattern=context != "inside_big_range",
                        vx=float(vx), hz_top=float(hz["top"]), restart=rs, seq=seq[rs_j:]))
    return out
