"""Owner HH/HL pattern, rule v4 (2026-10-10). v3 passed batch-5 precision (15/22 = 0.68); its recall
was left undecided. v4 changes ONLY how resistance lines are used (owner, 2026-10-10):
  * lines END once a close has stood above them (bigrange_v4);
  * only RECENT lines block: lines whose last touch is at/after the start of the current big leg
    (the latest confirmed 4-ATR swing low before t). Old lines, from before that low, never block;
  * a recent line that is farther above than the base is tall does not block either (as v3);
  * every non-blocking line above the close is returned as a bonus level (`bonus_levels`, with age
    old / recent_far), for the probability study: crossing one soon after the breakout is the
    owner's 'confidence bonus'. It does not create a new event.
Everything below up to the line logic is v3 unchanged.

v3 header follows.

Built from v2 with the changes the owner agreed after batch 4 and the missed-breakout review:
  1. Higher low on the big scale: a small swing low that is lower than the previous small low
     still counts as a higher low if it stays above the previous BIG swing low (zigzag BIG_K),
     and the structure then restarts from that big low (owner: 6290, 2496).
  2. Limit-up exception: a close up >= LIMIT_UP (TW 10% limit) counts as volume-confirmed even on
     low volume, because a locked limit-up trades thin (owner: 6290 2026-04-20).
  3. Big range by drawn lines (bigrange.py, body-edge touches, big swing 4 ATR). A resistance line
     above the close blocks only if it is no farther above than the current base is tall
     (close - restart low); a farther line means the current base is its own range (owner: 3272).
  4. Scale tag: big_range = no resistance line above at all; small_range = only far lines above
     (a later break of that far line would be a separate, possibly stronger event; owner: 2345,
     2375). inside_big_range = a near line blocks, not a pattern.
  5. Liquidity floor: mean raw turnover of the prior 20 sessions >= MIN_TURNOVER thousand TWD
     (NT$1m; 8423 traded NT$0.37m, the thinnest owner pick NT$1.06m).
Prices are total-return adjusted (adjprice.load). Everything on day t uses data through t,
with swings confirmed by t-1.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

import bigrange_v4
from detect import pivots_atr

K, BIG_K, LO_CUT, HI_CUT, HI20, VOLX, PENDING = 1.5, 4.0, -0.5, 0.75, 20, 1.5, 5
LIMIT_UP, MIN_TURNOVER = 0.095, 1_000


def _pivots(h, l, c, atr, k):
    ph, pl = pivots_atr(h, l, c, atr, k=k)
    return sorted([(i, cf, p, "H") for i, cf, p in ph] + [(i, cf, p, "L") for i, cf, p in pl], key=lambda x: x[1])


def _structure(piv, t, atr):
    """Zones and per-swing relations from swings confirmed by t-1 (same logic as v1/v2)."""
    zones, seq = {"H": [], "L": []}, []
    for i, cf, p, k in piv:
        if cf > t - 1:
            break
        zs = zones[k]
        if zs:
            g = (p - zs[-1]["ref"]) / atr[i]
            rel = "same" if LO_CUT <= g <= HI_CUT else ("higher" if g > HI_CUT else "lower")
        else:
            rel = "first"
        if rel == "same":
            z = zs[-1]; z["n"] += 1; z["top"] = max(z["top"], p); z["last"] = i
        else:
            zs.append(dict(ref=p, top=p, n=1, first=i, last=i, rel=rel))
        seq.append(dict(i=i, k=k, p=float(p), rel=rel))
    return zones, seq


def detect(df: pd.DataFrame) -> list[dict]:
    o, h, l, c = (df[x].to_numpy(float) for x in ("Open", "High", "Low", "Close"))
    v = df["VolumeLots"].to_numpy(float)
    atr = df["atr14_pct"].to_numpy(float) * c
    turnover = df["RawClose"].to_numpy(float) * v
    piv = _pivots(h, l, c, atr, K)
    big_lows = [(i, cf, p) for i, cf, p, k in _pivots(h, l, c, atr, BIG_K) if k == "L"]
    out, broken, pending = [], set(), {}
    for t in range(HI20 + 1, len(c)):
        zones, seq = _structure(piv, t, atr)
        if not zones["H"] or len(zones["L"]) < 2:
            continue
        hz = zones["H"][-1]
        key = (hz["first"], hz["ref"])
        if key in broken:
            continue
        if c[t] <= hz["top"]:
            pending.pop(key, None)
            continue
        if key not in pending:
            if c[t - 1] > hz["top"]:
                continue
            pending[key] = t
        if t - pending[key] > PENDING:
            continue
        mean_v = np.nanmean(v[t - HI20:t])
        vx = v[t] / mean_v if mean_v > 0 else np.nan
        limit_up = c[t] / c[t - 1] - 1 >= LIMIT_UP
        if not (c[t] > c[t - HI20:t].max() and (vx >= VOLX or limit_up)):
            continue
        broken.add(key)
        lows = [z for z in zones["L"] if z["first"] < t]
        last, prev = lows[-1], lows[-2]
        low_idx = [j for j, q in enumerate(seq) if q["k"] == "L"]
        rs_j = next((j for j in reversed(low_idx) if seq[j]["rel"] in ("lower", "first")), low_idx[0])
        rs = seq[rs_j]["i"]
        big_hhhl = False
        if last["rel"] == "higher":
            cat = "bottom" if len(lows) >= 3 and prev["rel"] == "lower" else "hhhl"
        elif last["rel"] == "same" or last["n"] >= 2 or hz["n"] >= 2:
            cat = "range"
        else:
            # change 1: a lower small low still above the previous big swing low is a higher low
            prior_big = [(i, p) for i, cf, p in big_lows if cf <= t - 1 and i < last["first"]]
            if not prior_big or not (last["ref"] - prior_big[-1][1] > HI_CUT * atr[last["first"]]):
                continue
            cat, big_hhhl = "hhhl", True
            rs = prior_big[-1][0]
            rs_j = next((j for j, q in enumerate(seq) if q["i"] >= rs), rs_j)
        base = c[t] - l[rs]
        leg = [i for i, cf, p in big_lows if cf <= t - 1 and i < t]
        leg_start = min(leg[-1], rs) if leg else rs
        lines = [ln for ln in bigrange_v4.resistance_lines(o, h, l, c, atr, t, leg_start) if ln["level"] > c[t]]
        blocking = [(ln["level"], ln["touches"]) for ln in lines if ln["age"] == "recent" and ln["level"] - c[t] <= base]
        bonus = [dict(level=ln["level"], touches=ln["touches"], age="old" if ln["age"] == "old" else "recent_far")
                 for ln in lines if (ln["level"], ln["touches"]) not in blocking]
        above = [(ln["level"], ln["touches"]) for ln in lines]
        scale = "inside_big_range" if blocking else ("small_range" if bonus else "big_range")
        liquid = float(np.nanmean(turnover[t - HI20:t])) >= MIN_TURNOVER
        out.append(dict(t=t, cat=cat, big_hhhl=big_hhhl, scale=scale, limit_up=bool(limit_up), liquid=liquid,
                        pattern=(not blocking) and liquid, vx=float(vx), hz_top=float(hz["top"]), restart=rs,
                        lines_above=above, blocking=blocking, bonus_levels=bonus, leg_start=leg_start, seq=seq[rs_j:]))
    return out
