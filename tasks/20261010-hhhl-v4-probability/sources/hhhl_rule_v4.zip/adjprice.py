"""Total-return adjusted OHLC for the atlas-v2 window (cash dividends included).

adjusted = raw price x product of corporate-action price_factor for every event with
ex_date after that row and on/before the atlas cutoff. price_factor is reference price /
previous close, so a cash dividend's ex-date gap disappears. ATR14 (Wilder) is recomputed
on the adjusted bars so an ex-date no longer shows up as a huge true range.
"""
from __future__ import annotations

import sqlite3
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

TABLES = Path("D:/Project/Stock/tasks/20261004-feature-discrimination-atlas/datasets/atlas-v2/tables")
ACTIONS = Path("D:/Project/Stock/shioaji_stock_prices/data/corporate_actions.sqlite")
CUTOFF = "2026-08-14"


@lru_cache(maxsize=1)
def _factors() -> pd.DataFrame:
    con = sqlite3.connect(f"file:{ACTIONS.as_posix()}?mode=ro", uri=True)
    try:
        f = pd.read_sql("select code, ex_date, event_type, price_factor from corporate_actions", con)
    finally:
        con.close()
    f["price_factor"] = pd.to_numeric(f["price_factor"], errors="coerce")
    f = f[f["ex_date"].notna() & (f["price_factor"] > 0) & (f["ex_date"] <= CUTOFF)]
    f["code"] = f["code"].astype(str)
    # the same event can be listed by more than one feed; apply it once per code and day
    return f.drop_duplicates(["code", "ex_date"])


def load(code: str) -> pd.DataFrame:
    cols = ["asof_date", "RawOpen", "RawHigh", "RawLow", "RawClose", "VolumeLots", "atr14_pct"]
    df = pd.read_parquet(TABLES / f"{code}.parquet", columns=cols)
    df = df.dropna(subset=["RawOpen", "RawHigh", "RawLow", "RawClose"]).reset_index(drop=True)
    d = df["asof_date"].astype(str).str[:10].to_numpy()
    ev = _factors()
    ev = ev[ev["code"] == str(code)].sort_values("ex_date")
    mult = np.ones(len(df))
    for ex, fac in zip(ev["ex_date"], ev["price_factor"]):
        mult[d < ex] *= fac
    for raw, out in (("RawOpen", "Open"), ("RawHigh", "High"), ("RawLow", "Low"), ("RawClose", "Close")):
        df[out] = df[raw].to_numpy(float) * mult
    h, l, c = df["High"].to_numpy(), df["Low"].to_numpy(), df["Close"].to_numpy()
    tr = np.maximum(h - l, np.maximum(np.abs(h - np.r_[np.nan, c[:-1]]), np.abs(l - np.r_[np.nan, c[:-1]])))
    tr[0] = h[0] - l[0]
    atr = np.full(len(df), np.nan)
    if len(df) >= 14:
        atr[13] = tr[:14].mean()
        for i in range(14, len(df)):
            atr[i] = (atr[i - 1] * 13 + tr[i]) / 14
    df["atr14_pct"] = atr / c
    df["div_factor"] = mult
    return df
