"""Drawn resistance lines for rule v4 (owner, 2026-10-10).

Same line drawing as bigrange.py (body-edge touches of 1.5-ATR and 4-ATR swings within the SHOW
sessions before t, clustered within TOL x ATR, >= 2 touches including a big swing), plus:
  * a line has an END: once a close has stood above it after its last touch, it is no longer
    resistance and is dropped;
  * RECENT vs OLD is set by structure, not by days: a line is recent if its last touch is at or
    after `restart` (the low the current structure started from), old otherwise.
Returned lines carry level, touches, first/last touch index and age class, so a caller can decide
which block and which are later 'bonus' levels.
"""
from __future__ import annotations

import numpy as np

from detect import pivots_atr

SMALL_K, BIG_K, TOL, SHOW = 1.5, 4.0, 0.75, 200


def resistance_lines(o, h, l, c, atr, t, restart):
    s = max(0, t - SHOW)
    top = np.maximum(o, c)
    sh, _ = pivots_atr(h, l, c, atr, k=SMALL_K)
    bh, _ = pivots_atr(h, l, c, atr, k=BIG_K)
    small = {i: float(top[i]) for i, cf, p in sh if cf <= t - 1 and i >= s}
    big = {i: float(top[i]) for i, cf, p in bh if cf <= t - 1 and i >= s}
    pts = sorted({**small, **big}.items(), key=lambda x: x[1])
    groups, cur = [], []
    for i, p in pts:
        if cur and abs(p - np.median([q for _, q in cur])) > TOL * atr[i]:
            groups.append(cur)
            cur = []
        cur.append((i, p))
    if cur:
        groups.append(cur)
    out = []
    for g in groups:
        if len(g) < 2 or not any(i in big for i, _ in g):
            continue
        level = float(np.median([p for _, p in g]))
        last = max(i for i, _ in g)
        if last + 1 < t and (c[last + 1:t] > level).any():
            continue  # broken: a close stood above it after its last touch
        out.append(dict(level=level, touches=len(g), first=min(i for i, _ in g), last=last,
                        age="recent" if last >= restart else "old"))
    return out
