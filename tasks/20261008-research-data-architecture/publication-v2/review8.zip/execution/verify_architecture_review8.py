"""Bounded backup-completion and atomic-restore drill; preserve prior evidence."""

import json
import subprocess
import time
import zipfile
from pathlib import Path

from research_core.artifact_backup import backup_sources, restore_backup, verify_backup
from research_core.artifact_store import canonical, file_digest, read_json, write_json
from research_core.derived_cache import verify_cache


def main() -> None:
    started = time.perf_counter()
    project = Path("D:/Project/Stock")
    version = project / "research_cache/price-bases/39c540d511abb4438644e06dfe167162a601a863db28363f29d08e02fbc0d6e7"
    destination = Path("D:/StockResearchRestore/architecture-review8-20261008")
    dataset = project / "tasks/20261008-research-data-architecture/datasets/validation-review8-01"
    bundle = Path("tasks/20261008-research-data-architecture/publication-v2/review8.zip")
    assert not destination.exists() and not dataset.exists() and not bundle.exists()
    prior_packets = {
        Path("tasks/20261008-research-data-architecture/publication-v1/bundle.zip"): "7ddceebe615317ba854eede92eb0480357895af358a778b99a1e8ead58212477",
        Path("tasks/20261008-research-data-architecture/publication-v1/review2.zip"): "427e22981cd26bc911195db74e6cb2f5d1bc3d1271ced1b0274ef1d4fa94b052",
        Path("tasks/20261008-research-data-architecture/publication-v2/bundle.zip"): "a7c4045fd1f35e0a8c42451e9d31a6df346dc01198663b70f85baf84ac10bafc",
    }
    assert all(file_digest(path) == digest for path, digest in prior_packets.items())
    cache_hash = file_digest(version / "manifest.json")
    cache = verify_cache(version)
    backup_root = Path("D:/StockResearchBackup")
    backup = backup_sources({f"research_cache/price-bases/{version.name}": version}, backup_root)
    attempt_path, completion_path = Path(backup["attempt_path"]), Path(backup["completion_path"])
    completion = read_json(completion_path)
    assert completion["complete"] is True and completion["state"] == "completed"
    assert completion["attempt"] == {"path": attempt_path.relative_to(backup_root).as_posix(), "sha256": file_digest(attempt_path)}
    assert completion["snapshot"] == {
        "path": Path(backup["manifest_path"]).relative_to(backup_root).as_posix(),
        "id": backup["snapshot_id"], "sha256": file_digest(Path(backup["manifest_path"])),
    }
    verify_backup(Path(backup["manifest_path"]))
    restored = restore_backup(Path(backup["manifest_path"]), destination)
    restored_cache = destination / "research_cache/price-bases" / version.name
    assert verify_cache(restored_cache)["version_id"] == cache["version_id"]
    assert file_digest(version / "manifest.json") == file_digest(restored_cache / "manifest.json") == cache_hash
    assert restored["files"] == backup["files"]
    assert all(file_digest(path) == digest for path, digest in prior_packets.items())
    sources = {
        "cache/manifest.json": version / "manifest.json",
        "backup/snapshot.json": Path(backup["manifest_path"]),
        "backup/attempt.json": attempt_path,
        "backup/completion.json": completion_path,
        "backup/restore-receipt.json": destination / "restore-receipt.json",
        "reader-code/derived_cache.py": Path("research_core/derived_cache.py"),
        "backup-code/artifact_backup.py": Path("research_core/artifact_backup.py"),
        "backup-code/artifact_store.py": Path("research_core/artifact_store.py"),
        "execution/verify_architecture_review8.py": Path(__file__),
    }
    receipt = {
        "schema": "stock-architecture-review8-drill.v1", "complete": True,
        "execution_head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "cache_version": cache["version_id"], "cache_manifest_sha256_before_after": cache_hash,
        "backup": backup, "restore_destination": str(destination), "restore": restored,
        "prior_packets_unchanged": {str(path): digest for path, digest in prior_packets.items()},
        "retained_members": {name: {"bytes": path.stat().st_size, "sha256": file_digest(path)} for name, path in sources.items()},
        "elapsed_seconds": round(time.perf_counter() - started, 3),
        "limitations": "Existing immutable 25-symbol v2 cache only; no formula rebuild, download, strategy study or annotation acceptance. Same-drive backup.",
    }
    dataset.mkdir(parents=True)
    write_json(dataset / "completion.json", receipt)
    with zipfile.ZipFile(bundle, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, path in sources.items():
            archive.writestr(name, path.read_bytes())
        archive.writestr("receipt.json", canonical(receipt))
    with zipfile.ZipFile(bundle) as archive:
        assert set(archive.namelist()) == set(sources) | {"receipt.json"}
        assert archive.testzip() is None
        for name, path in sources.items():
            assert archive.read(name) == path.read_bytes()
        assert json.loads(archive.read("receipt.json")) == receipt
    print(json.dumps({"backup": backup, "restore": restored, "dataset": str(dataset), "destination": str(destination),
                      "bundle": str(bundle), "bundle_bytes": bundle.stat().st_size, "bundle_sha256": file_digest(bundle),
                      "elapsed_seconds": receipt["elapsed_seconds"]}))


if __name__ == "__main__":
    main()
