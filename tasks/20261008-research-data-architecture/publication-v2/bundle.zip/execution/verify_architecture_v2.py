"""Additive bounded v2 infrastructure drill from the original frozen 25 inputs."""

import json
import subprocess
import time
import zipfile
from pathlib import Path

import pandas as pd

from research_core.artifact_backup import backup_sources, restore_backup
from research_core.artifact_store import canonical, file_digest, verify_files, write_json
from research_core.derived_cache import BASES, build_cache, verify_cache
from scripts.verify_research_cache import recompute


def main() -> None:
    started = time.monotonic()
    task = Path("tasks/20261008-research-data-architecture")
    inputs = Path("D:/Project/Stock/research_cache/input-snapshots/architecture-v1-25-cases")
    old = Path("D:/Project/Stock/research_cache/price-bases/71928e94ce30c6bd1ceb7eee2d3a7a9955cea7d72a7e9e30fe9e45695a0f8907")
    evidence = Path("D:/Project/Stock/tasks/20261008-research-data-architecture/datasets/validation-v2-01")
    destination = Path("D:/StockResearchRestore/architecture-v2-20261008")
    bundle = task / "publication-v2/bundle.zip"
    assert not evidence.exists() and not destination.exists() and not bundle.exists()
    assert not subprocess.check_output(["git", "status", "--porcelain"], text=True).strip(), "seal code before drill"
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    preserved = {str(path): file_digest(path) for path in (old / "manifest.json", task / "publication-v1/bundle.zip", task / "publication-v1/review2.zip")}
    before = {path.name: file_digest(path) for path in inputs.iterdir() if path.is_file()}
    input_receipt = json.loads((inputs / "input-receipt.json").read_bytes())
    verify_files(inputs, input_receipt["artifacts"])
    with zipfile.ZipFile(task / "publication-v1/bundle.zip") as archive:
        assert archive.read("inputs/input-receipt.json") == (inputs / "input-receipt.json").read_bytes()
    cases_codes = sorted({str(case["code"]) for case in json.loads((inputs / "cases.json").read_bytes())})
    raw = pd.read_parquet(inputs / "prices.parquet")
    assert cases_codes == input_receipt["codes"] == sorted(raw.Code.astype(str).unique())
    assert len(cases_codes) == 25 and len(raw) == input_receipt["rows"] == 46225
    assert before["cases.json"] == input_receipt["source_cases_sha256"]
    assert before["actions.parquet"] == input_receipt["source_actions_sha256"]
    verify_cache(old)
    evidence.mkdir(parents=True, exist_ok=False)
    input_audit = {"schema": "stock-original-input-audit.v1", "complete": True, "hashes": before, "codes": cases_codes, "rows": len(raw), "original_portable_receipt_matches": True}
    write_json(evidence / "input-audit.json", input_audit)
    kwargs = {"prices": inputs / "prices.parquet", "actions": inputs / "actions.parquet", "calendar": inputs / "calendar.json", "root": Path("D:/Project/Stock/research_cache"), "cutoff": "2026-08-14"}
    built = build_cache(**kwargs)
    version = Path(built["manifest_path"]).parent
    manifest = verify_cache(version)
    assert manifest["identity"]["definitions"]["prices"] == "price-basis.v2"
    assert version != old and manifest["codes"] == cases_codes
    manifest_hash = file_digest(version / "manifest.json")
    parity = recompute(version)
    assert parity["complete"] and len(parity["checked"]) == 75
    write_json(evidence / "direct-parity.json", parity)
    differences = []
    for basis in BASES:
        for code in cases_codes:
            previous = pd.read_parquet(old / basis / code / "daily.parquet", columns=["Date", "Quality", "quality_reason"])
            current = pd.read_parquet(version / basis / code / "daily.parquet", columns=["Date", "Quality", "quality_reason"])
            assert previous.Date.equals(current.Date)
            changed = previous.Quality.ne(current.Quality) | previous.quality_reason.fillna("").ne(current.quality_reason.fillna(""))
            for index in current.index[changed]:
                differences.append({"basis": basis, "code": code, "date": current.Date.iloc[index].date().isoformat(), "before_quality": bool(previous.Quality.iloc[index]), "after_quality": bool(current.Quality.iloc[index]), "before_reason": previous.quality_reason.iloc[index], "after_reason": current.quality_reason.iloc[index]})
    quality = {"schema": "stock-price-quality-correction.v1", "complete": True, "old_version": old.name, "new_version": version.name, "changed_rows": differences, "comparison": "quality flags/reasons only; no outcome or pattern probability evaluation", "coverage": manifest["coverage"]}
    write_json(evidence / "quality-correction.json", quality)
    reused = build_cache(**kwargs)
    assert reused["computed_symbols"] == 0 and reused["reused_symbols"] == 25
    backup = backup_sources({f"research_cache/price-bases/{version.name}": version}, Path("D:/StockResearchBackup"))
    restored = restore_backup(Path(backup["manifest_path"]), destination)
    verify_cache(destination / "research_cache/price-bases" / version.name)
    assert restored["files"] == backup["files"]
    assert before == {path.name: file_digest(path) for path in inputs.iterdir() if path.is_file()}
    assert all(file_digest(Path(path)) == digest for path, digest in preserved.items())
    verify_cache(version)
    assert file_digest(version / "manifest.json") == manifest_hash
    sources = {
        "cache/manifest.json": version / "manifest.json",
        "inputs/input-receipt.json": inputs / "input-receipt.json",
        "validation/input-audit.json": evidence / "input-audit.json",
        "validation/direct-parity.json": evidence / "direct-parity.json",
        "validation/quality-correction.json": evidence / "quality-correction.json",
        "backup/snapshot.json": Path(backup["manifest_path"]),
        "backup/restore-receipt.json": destination / "restore-receipt.json",
        "execution/verify_architecture_v2.py": Path(__file__),
        "execution/verify_research_cache.py": Path("scripts/verify_research_cache.py"),
        "execution/artifact_backup.py": Path("research_core/artifact_backup.py"),
    }
    sources.update({f"implementation/{path.name}": path for path in (version / "implementation").iterdir() if path.is_file()})
    receipt = {"schema": "stock-architecture-v2-drill.v1", "complete": True, "execution_head": head, "build": built, "reuse": reused, "manifest_sha256_before_after": manifest_hash, "input_audit": input_audit, "quality_changed_rows": len(differences), "direct_parity_pairs": len(parity["checked"]), "backup": backup, "restore": restored, "restore_destination": str(destination), "preserved_original_hashes": preserved, "elapsed_seconds": time.monotonic() - started, "retained_members": {name: {"bytes": path.stat().st_size, "sha256": file_digest(path)} for name, path in sources.items()}, "limitations": "Frozen 25-symbol infrastructure drill only; no download, forward outcomes, new periods or rerun of v1 pattern compatibility. Same-drive backup; owner annotations pending."}
    write_json(evidence / "completion.json", receipt)
    bundle.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(bundle, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, path in sources.items():
            archive.writestr(name, path.read_bytes())
        archive.writestr("receipt.json", canonical(receipt))
    with zipfile.ZipFile(bundle) as archive:
        assert set(archive.namelist()) == set(sources) | {"receipt.json"}
        for name, path in sources.items():
            assert archive.read(name) == path.read_bytes()
        assert json.loads(archive.read("receipt.json")) == receipt
    print(json.dumps({"build": built, "reuse": reused, "quality_changed_rows": len(differences), "parity_pairs": len(parity["checked"]), "backup": backup, "restore": restored, "bundle_bytes": bundle.stat().st_size, "bundle_sha256": file_digest(bundle), "evidence": str(evidence), "elapsed_seconds": receipt["elapsed_seconds"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
