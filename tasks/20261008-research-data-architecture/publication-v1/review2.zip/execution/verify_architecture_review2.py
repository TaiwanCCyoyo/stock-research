"""Bounded post-review restore drill; preserve every existing cache and backup."""

import json
import subprocess
import zipfile
from pathlib import Path

from research_core.artifact_backup import backup_sources, restore_backup
from research_core.artifact_store import canonical, file_digest, write_json
from research_core.derived_cache import verify_cache


def main() -> None:
    version = Path("D:/Project/Stock/research_cache/price-bases/71928e94ce30c6bd1ceb7eee2d3a7a9955cea7d72a7e9e30fe9e45695a0f8907")
    destination = Path("D:/StockResearchRestore/architecture-review2-20261008")
    bundle = Path("tasks/20261008-research-data-architecture/publication-v1/review2.zip")
    receipt_path = Path(".tmp/architecture-review2-completion.json")
    assert not destination.exists() and not bundle.exists() and not receipt_path.exists()
    cache_hash = file_digest(version / "manifest.json")
    cache = verify_cache(version)
    backup = backup_sources({f"research_cache/price-bases/{version.name}": version}, Path("D:/StockResearchBackup"))
    restored = restore_backup(Path(backup["manifest_path"]), destination)
    verify_cache(version)
    assert file_digest(version / "manifest.json") == cache_hash
    assert restored["files"] == backup["files"]
    sources = {
        "cache/manifest.json": version / "manifest.json",
        "backup/snapshot.json": Path(backup["manifest_path"]),
        "backup/restore-receipt.json": destination / "restore-receipt.json",
        "reader-code/derived_cache.py": Path("research_core/derived_cache.py"),
        "backup-code/artifact_backup.py": Path("research_core/artifact_backup.py"),
        "execution/verify_architecture_review2.py": Path(__file__),
    }
    receipt = {
        "schema": "stock-architecture-review2-drill.v1",
        "complete": True,
        "execution_head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
        "cache_version": cache["version_id"],
        "cache_manifest_sha256_before_after": cache_hash,
        "backup": backup,
        "restore_destination": str(destination),
        "restore": restored,
        "retained_members": {name: {"bytes": path.stat().st_size, "sha256": file_digest(path)} for name, path in sources.items()},
        "limitations": "Existing 25-symbol cache only; no new download, formula build, research outcomes or entire-program acceptance. Same-drive backup.",
    }
    write_json(receipt_path, receipt)
    with zipfile.ZipFile(bundle, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, path in sources.items():
            archive.writestr(name, path.read_bytes())
        archive.writestr("receipt.json", canonical(receipt))
    with zipfile.ZipFile(bundle) as archive:
        assert set(archive.namelist()) == set(sources) | {"receipt.json"}
        for name, path in sources.items():
            assert archive.read(name) == path.read_bytes()
        assert json.loads(archive.read("receipt.json")) == receipt
    print(json.dumps({"backup": backup, "restore": restored, "destination": str(destination), "bundle": str(bundle), "bundle_bytes": bundle.stat().st_size, "bundle_sha256": file_digest(bundle)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
